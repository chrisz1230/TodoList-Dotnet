namespace TodolistAPI.Models
{
    public class TodoItem
    {
        public int TodoItemId { get; set; }
        public string? Description { get; set; }
    }
}
